import Data.Ratio (Rational, (%), numerator, denominator)

test1 :: Integer -> [Rational]
test1 b =
        zipWith (+) fs (reverse fs)
        where
        fs = zipWith (\ n d -> n % (succ d)) [0 .. b] (reverse [0 .. b])

toSmall :: [Rational] -> Integer 
toSmall fs =                            -- numerators modulo 5  +
           sum (numRems ++ denRems)     -- denominators modulo 5
           where
           nums    = map numerator   fs
           dens    = map denominator fs
           numRems = map (\b -> rem b 5) nums
           denRems = map (\b -> rem b 5) dens


main = putStrLn $  
       concat 
       ["b = ",                   shows b "\n",
        "toSmall (test1 b) =  ",  show (toSmall (test1 b))
       ]
       where
       b = 640000




{- ***********************************************************************

  b    |  time [sec] 

-- toSmall ∘ test1 -------------------------------------------------------
        |
        |    Agda                 |    GHC
-----------------------------------------------       
   1024 |    0.2                  |
   2048 |    0.5
   4096 |    1.3
   8192 |    3.1
        |
  32768 |   15.5                  |    0.03
  
  +fr  applies  b  times.
  time =  about O( b*(log b) ). 

 320000 |                         |    0.32
 640000 |                         |    0.60 
-}
